Hi��
	I had finished the capstone project by myself.
	My name is Zhu Wangwang!
	My e-mail address: zhuwangwang@sjtu.edu.cn
	Thanks for your review!